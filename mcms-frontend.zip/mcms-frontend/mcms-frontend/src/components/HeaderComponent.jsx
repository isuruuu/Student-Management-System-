import React from 'react';
import { Link } from 'react-router-dom';

export const HeaderComponent = () => {
  return (
    <div>
        <header>
            <nav className='navbar navbar-dark bg-darkbrown'> 
                <div className="container-fluid d-flex justify-content-between">
                    <Link to="/" className="navbar-brand">Music Class Management System</Link>
                    <ul className="navbar-nav d-flex flex-row">
                        
                        <li className="nav-item">
                            <Link to="/aboutUs" className="nav-link">About Us</Link>
                        </li>
                        <li className="nav-item">
                            <Link to="/" className="nav-link">LogOut</Link>
                        </li>
                        
                    </ul>
                </div>
            </nav>
        </header>
        <style>
            {`
            .navbar-nav .nav-item {
                margin-left: 50px;
            }
            .nav-link.active, .nav-link:hover, .navbar.bg .nav-link:hover, .navbar.bg .nav-link.active {
              opacity: 3;
            }

            .navbar-brand {
                margin-right: 300px; 
            }

            .bg-darkbrown {
                background-color: #654321;
            }
            `}
        </style>
    </div>
  )
}

export default HeaderComponent;










