import React, { useState } from 'react';

const SearchCourseComponent = ({ courses, setFilteredCourses }) => {
    const [searchQuery, setSearchQuery] = useState('');

    const handleSearchInputChange = (e) => {
        const query = e.target.value.toLowerCase();
        setSearchQuery(query);
        if (query === '') {
            
            setFilteredCourses(courses);
        }
    };

    const handleSearchSubmit = (e) => {
        e.preventDefault();
        const filteredCourses = courses.filter(course =>
            course.courseName.toLowerCase().includes(searchQuery)
        );
        setFilteredCourses(filteredCourses);
    };

    return (
        <nav className="navbar navbar-light bg-light">
            <div className="container-fluid">
                <form className="d-flex" onSubmit={handleSearchSubmit}>
                    <input
                        className="form-control me-2"
                        type="search"
                        placeholder="Search by course name"
                        aria-label="Search"
                        value={searchQuery}
                        onChange={handleSearchInputChange}
                    />
                    <button className="btn btn-outline-warning" type="submit">Search</button>
                </form>
            </div>
        </nav>
    );
};

export default SearchCourseComponent;
