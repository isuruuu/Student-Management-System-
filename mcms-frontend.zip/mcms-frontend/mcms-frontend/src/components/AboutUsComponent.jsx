import React from 'react';
import backgroundImage from '../images/F.jpg';

const AboutUsComponent = () => {
  return (
    <div style={{ backgroundImage: `url('${backgroundImage}')`, backgroundSize: 'cover', minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ backgroundColor: 'rgba(255, 255, 255, 0.8)', padding: '20px', borderRadius: '10px', textAlign: 'center' }}>
        <h1 style={{ color: 'brown' }}>Welcome to Rhythmic Realm</h1>
        <p style={{ color: 'black' }}>
          Welcome to Rhythmic Realm! We're a passionate music class dedicated to nurturing talent, fostering creativity, and connecting communities through the power of music. Join us and embark on a musical journey filled with inspiration, guidance, and endless possibilities.
        </p>
      </div>
    </div>
  );
};

export default AboutUsComponent;

