import React, { useEffect, useState } from 'react';
import { deleteCourse, listCourse } from '../services/CourseService';
import HeaderComponent from './HeaderComponent';
import FooterComponent from './FooterComponent';
import { useNavigate } from 'react-router-dom';
import SearchCourseComponent from './SearchCourseComponent';

const ListCourseComponent = () => {
    const [courses, setCourses] = useState([]);
    const [filteredCourses, setFilteredCourses] = useState([]);
    const navigator = useNavigate();

    useEffect(() => {
        getAllCourses();
    }, []);

    function getAllCourses() {
        listCourse()
            .then((response) => {
                setCourses(response.data);
                setFilteredCourses(response.data);
            })
            .catch((error) => {
                console.error(error);
            });
    }

    function addNewCourse() {
        navigator('/add-course');
    }

    function updateCourse(id) {
        navigator(`/edit-course/${id}`);
    }

    function removeCourse(id) {
        console.log(id);

        deleteCourse(id)
            .then((response) => {
                getAllCourses();
            })
            .catch((error) => {
                console.error(error);
            });
    }

    const handleSearchInputChange = (e) => {
        const query = e.target.value.toLowerCase();
        const filteredCourses = courses.filter((course) =>
            course.courseName.toLowerCase().includes(query)
        );
        setFilteredCourses(filteredCourses);
    };

    return (
        <>
            <HeaderComponent />
            <div className='container' style={{ maxHeight: '87vh', overflowY: 'auto', scrollbarWidth: 'none' }}>
                <SearchCourseComponent courses={courses} setFilteredCourses={setFilteredCourses} /> 
                <h2 className='text-center' style={{ color: 'brown', fontSize: '35px', marginTop: '5px' }}>List of Courses</h2>
                <button className='btn btn-outline-success mb-2' onClick={addNewCourse}>
                    Add Course
                </button>
                <table className='table table-bordered border-secondary'>
                    <thead>
                        <tr>
                            <th>Course Id</th>
                            <th>Course Name</th>
                            <th>Course Description</th>
                            <th>Course Instructor</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredCourses.length > 0 ? (
                            filteredCourses.map((course) => (
                                <tr key={course.id}>
                                    <td>{course.id}</td>
                                    <td>{course.courseName}</td>
                                    <td>{course.description}</td>
                                    <td>{course.instructor}</td>
                                    <td>
                                        <button className='btn btn-outline-info' onClick={() => updateCourse(course.id)}>
                                            Update
                                        </button>
                                        <button
                                            className='btn btn-outline-danger'
                                            onClick={() => removeCourse(course.id)}
                                            style={{ marginLeft: '10px' }}
                                        >
                                            Delete
                                        </button>
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan="5" className="text-center">
                                    No courses found
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
            <FooterComponent />
        </>
    );
};

export default ListCourseComponent;



