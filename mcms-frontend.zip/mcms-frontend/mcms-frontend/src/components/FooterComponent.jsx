import React from 'react';
import { Link } from 'react-router-dom'; 

export const FooterComponent = () => {
  return (
    <div>
      <footer className='footer'>
        <span>All right reserved 2024 by Rhythmic Realm</span>
      </footer>
    </div>
  );
};

export default FooterComponent;

