import React from 'react';
import { Link } from 'react-router-dom';
import HeaderComponent from './HeaderComponent';
import FooterComponent from './FooterComponent';
import backgroundImage from '../images/K.jpg';

const MainComponent = () => {
 
  const containerStyle = {
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    padding: '40px',
    margin: '10px',
    borderRadius: '5px',
  };

  const buttonStyle = {
    backgroundColor: 'green',
    color: '#fff',
    padding: '10px 20px',
    textDecoration: 'none',
    borderRadius: '5px',
  };

  return (
    <>
    <HeaderComponent/>
    <div style={{backgroundSize: 'cover',display:'flex', minHeight: '90vh', backgroundImage: `url(${backgroundImage})`}}>
    <div className="container"> 
      <div className="container" style={containerStyle}>
        <h2 style={{ color: 'white'}}>Students</h2>
        <Link to="/students" className="button" style={buttonStyle}>View Students</Link>
      </div>
      
      
      <div className="container" style={containerStyle}>
        <h2 style={{ color: 'white'}}>Courses</h2>
        <Link to="/courses" className="button" style={buttonStyle}>View Courses</Link>
      </div>
      
     
      <div className="container" style={containerStyle}>
        <h2 style={{ color: 'white'}}>Instructors</h2>
        <Link to="/instructors" className="button" style={buttonStyle}>View Instructors</Link>
      </div>
    </div>
    </div>
    <FooterComponent/>
    </>
  );
};

export default MainComponent;
