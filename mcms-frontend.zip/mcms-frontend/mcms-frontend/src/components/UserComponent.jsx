import React, { useState } from 'react';
import axios from 'axios';
import backgroundImage from '../images/I.jpg'; 
const UserComponent = ({ onUserAdded }) => {
  const [formData, setFormData] = useState({
    firstname: '',
    lastname: '',
    email: '',
    password: '',
    dob: '',
  });
  const [error, setError] = useState(null); 

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('http://localhost:8080/api/users/add', formData)
      .then(response => {
        console.log('User added successfully:', response.data);
        if (typeof onUserAdded === 'function') {
          onUserAdded(response.data);
        } else {
          console.error('onUserAdded is not a function');
        }
        setFormData({
          firstname: '',
          lastname: '',
          email: '',
          password: '',
          dob: '',
        });
        setError(null);
      })
      .catch(error => {
        console.error('Error adding user:', error.response.data);
        setError(error.response.data.message); 
      });
  };

  return (
    <div style={{ 
      backgroundImage: `url(${backgroundImage})`, 
      backgroundAttachment: 'fixed', 
      minHeight: '100vh', 
      display: 'flex', 
      justifyContent: 'center', 
      alignItems: 'center' 
    }}>
      <div style={{ 
        width: '500px', 
        padding: '20px', 
        border: '1px solid black', 
        borderRadius: '5px', 
        background: 'rgba(210, 180, 140, 0.8)',
      }}>
        <h2>User Registration</h2>
        {error && <div className="alert alert-danger">{error}</div>} 
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label htmlFor="firstname">First Name</label>
            <input type="text" id="firstname" name="firstname" value={formData.firstname} onChange={handleChange} className="form-control" required />
          </div>
          <div className="mb-3">
            <label htmlFor="lastname">Last Name</label>
            <input type="text" id="lastname" name="lastname" value={formData.lastname} onChange={handleChange} className="form-control" required />
          </div>
          <div className="mb-3">
            <label htmlFor="email">Email</label>
            <input type="email" id="email" name="email" value={formData.email} onChange={handleChange} className="form-control" required />
          </div>
          <div className="mb-3">
            <label htmlFor="password">Password</label>
            <input type="password" id="password" name="password" value={formData.password} onChange={handleChange} className="form-control" required />
          </div>
          <div className="mb-3">
            <label htmlFor="dob">Date of Birth</label>
            <input type="date" id="dob" name="dob" value={formData.dob} onChange={handleChange} className="form-control" required />
          </div>
          <button type="submit" className="btn btn-primary">Register</button>
        </form>
      </div>
    </div>
  );
};

export default UserComponent;



