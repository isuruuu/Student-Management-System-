import React, { useEffect, useState } from 'react';
import { createCourse, getCourse, updateCourse } from '../services/CourseService';
import { useNavigate, useParams } from 'react-router-dom';
import backgroundImage from '../images/G.jpg';
import updateBackgroundImage from '../images/H.jpg';
import FooterComponent from './FooterComponent';

function CourseComponent() {
    const [courseName, setCourseName] = useState('');
    const [description, setDescription] = useState('');
    const [instructor, setInstructor] = useState('');

    const { id } = useParams();

    const [errors, setErrors] = useState({
        courseName: '',
        description: '',
        instructor: ''
    });

    const navigator = useNavigate();

    useEffect(() => {
        if (id) {
            getCourse(id)
                .then((response) => {
                    setCourseName(response.data.courseName);
                    setDescription(response.data.description);
                    setInstructor(response.data.instructor);
                })
                .catch((error) => {
                    console.error(error);
                });
        }
    }, [id]);

    function handleCourseName(e) {
        setCourseName(e.target.value);
    }

    function handleDescription(e) {
        setDescription(e.target.value);
    }

    function handleInstructor(e) {
        setInstructor(e.target.value);
    }

    function saveOrUpdateCourse(e) {
        e.preventDefault();

        if (validateForm()) {
            const course = { courseName, description, instructor };

            if (id) {
                updateCourse(id, course)
                    .then((response) => {
                        console.log(response.data);
                        navigator('/courses');
                    })
                    .catch((error) => {
                        console.error(error);
                    });
            } else {
                createCourse(course)
                    .then((response) => {
                        console.log(response.data);
                        navigator('/courses');
                    })
                    .catch((error) => {
                        console.error(error);
                    });
            }
        }
    }

    function validateForm() {
        let valid = true;

        const errorsCopy = { ...errors };

        if (courseName.trim()) {
            errorsCopy.courseName = '';
        } else {
            errorsCopy.courseName = 'Course name is required';
            valid = false;
        }
        if (description.trim()) {
            errorsCopy.description = '';
        } else {
            errorsCopy.description = 'Description is required';
            valid = false;
        }
        if (instructor.trim()) {
            errorsCopy.instructor = '';
        } else {
            errorsCopy.instructor = 'Instructor name is required';
            valid = false;
        }

        setErrors(errorsCopy);

        return valid;
    }

    function pageTitle() {
        if (id) {
            return <h2 className='text-center'>Update course</h2>;
        } else {
            return <h2 className='text-center'>Add course</h2>;
        }
    }

    const backgroundStyle = {
        backgroundImage: `url(${id ? updateBackgroundImage : backgroundImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        minHeight: '100vh',
        
    };

    return (
        <>
        <style>
            {`
                }
                .container {
                    height: calc(100vh - 200px);
                    overflow-y: auto; 
                }
                .card {
                    background-color: rgba(210, 180, 140, 0.8);
                    padding: 20px;
                    border-radius: 10px;
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                }
            `}
        </style>
        <div style={backgroundStyle}>
            <div className='container'>
                <br />
                <div className='row'>
                    <div className='card col-md-6 c offset-md-3 offset-md-3'>
                        {pageTitle()}
                        <div className='card-body'>
                            <form>
                                <div className='form-group mb-2'>
                                    <label className='form-label'>Course Name</label>
                                    <input
                                        type='text'
                                        placeholder='Enter the course name'
                                        value={courseName}
                                        className={`form-control ${errors.courseName ? 'is-invalid' : ''}`}
                                        onChange={handleCourseName}
                                    />
                                    {errors.courseName && <div className='invalid-feedback'>{errors.courseName}</div>}
                                </div>
                                <div className='form-group mb-2'>
                                    <label className='form-label'>Course description</label>
                                    <input
                                        type='text'
                                        placeholder='Enter the course description'
                                        value={description}
                                        className={`form-control ${errors.description ? 'is-invalid' : ''}`}
                                        onChange={handleDescription}
                                    />
                                    {errors.description && <div className='invalid-feedback'>{errors.description}</div>}
                                </div>
                                <div className='form-group mb-2'>
                                    <label className='form-label'>Course Instructor</label>
                                    <input
                                        type='text'
                                        placeholder='Enter the name of course instructor'
                                        value={instructor}
                                        className={`form-control ${errors.instructor ? 'is-invalid' : ''}`}
                                        onChange={handleInstructor}
                                    />
                                    {errors.instructor && <div className='invalid-feedback'>{errors.instructor}</div>}
                                </div>
                                <button className='btn btn-success' onClick={saveOrUpdateCourse}>
                                    Submit
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <FooterComponent/>
        </>
    );
}

export default CourseComponent;


