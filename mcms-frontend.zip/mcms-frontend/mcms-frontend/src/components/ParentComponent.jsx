import React, { useState } from 'react';
import UserComponent from './UserComponent';

const ParentComponent = () => {
  
  const handleUserAdded = (userData) => {
    
    console.log('User added:', userData);
  };

  return (
    <div>
      
      <UserComponent onUserAdded={handleUserAdded} />
    </div>
  );
};

export default ParentComponent;

