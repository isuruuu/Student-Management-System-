import React, { useState } from 'react';

const SearchStudentComponent = ({ students, setFilteredStudents }) => {
    const [searchQuery, setSearchQuery] = useState('');

    const handleSearchInputChange = (e) => {
        const query = e.target.value.toLowerCase();
        setSearchQuery(query);
        if (query === '') {
            
            setFilteredStudents(students);
        }
    };

    const handleSearchSubmit = (e) => {
        e.preventDefault();
        const filteredStudents = students.filter(student =>
            student.stdName.toLowerCase().includes(searchQuery)
        );
        setFilteredStudents(filteredStudents);
    };

    return (
        <nav className="navbar navbar-light bg-light">
            <div className="container-fluid">
                <form className="d-flex" onSubmit={handleSearchSubmit}>
                    <input
                        className="form-control me-2"
                        type="search"
                        placeholder="Search by name..."
                        aria-label="Search"
                        value={searchQuery}
                        onChange={handleSearchInputChange}
                    />
                    <button className="btn btn-outline-warning" type="submit">Search</button>
                </form>
            </div>
        </nav>
    );
};

export default SearchStudentComponent;



