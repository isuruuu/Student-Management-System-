import React from 'react';
import { Link } from 'react-router-dom';
import homeBackgroundImage from '../images/D.jpg';

const HomeComponent = () => {
  return (
    <div style={{ backgroundImage: `url(${homeBackgroundImage})`, backgroundSize: 'cover', minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ backgroundColor: 'rgba(0, 0, 0, 0.8)', padding: '70px', borderRadius: '40px', textAlign: 'center' }}>
        <h1 style={{ color: '#fff' }}>Welcome to Rhythmic Realm<br></br> Management System</h1>
        <br />
        <div>
          <Link to="/user" className="btn btn-outline-secondary">Register</Link>
          <br />
          <br />
          <Link to="/adminLogin" className="btn btn-outline-primary">Admin Login</Link>
          <br />
          <br />
          <Link to="/login" className="btn btn-outline-success">Login</Link>
        </div>
      </div>
    </div>
  );
};

export default HomeComponent;


