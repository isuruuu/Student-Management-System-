import React, { useState } from 'react';

const SearchInstructorComponent = ({ instructors, setFilteredInstructors }) => {
    const [searchQuery, setSearchQuery] = useState('');

    const handleSearchInputChange = (e) => {
        const query = e.target.value.toLowerCase();
        setSearchQuery(query);
        if (query === '') {
            
            setFilteredInstructors(instructors);
        }
    };

    const handleSearchSubmit = (e) => {
        e.preventDefault();
        const filteredInstructors = instructors.filter(instructor =>
            instructor.instructorName.toLowerCase().includes(searchQuery)
        );
        setFilteredInstructors(filteredInstructors);
    };

    return (
        <nav className="navbar navbar-light bg-light">
            <div className="container-fluid">
                <form className="d-flex" onSubmit={handleSearchSubmit}>
                    <input
                        className="form-control me-2"
                        type="search"
                        placeholder="Search by instructor name"
                        aria-label="Search"
                        value={searchQuery}
                        onChange={handleSearchInputChange}
                    />
                    <button className="btn btn-outline-warning" type="submit">Search</button>
                </form>
            </div>
        </nav>
    );
};

export default SearchInstructorComponent;

