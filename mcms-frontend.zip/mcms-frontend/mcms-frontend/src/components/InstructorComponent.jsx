import React, { useEffect, useState } from 'react';
import { createInstructor, getInstructor, updateInstructor } from '../services/InstructorService';
import { useNavigate, useParams } from 'react-router-dom';
import backgroundImage from '../images/I.jpg';
import updateBackgroundImage from '../images/J.jpg';
import FooterComponent from './FooterComponent';

const InstructorComponent = () => {
    const [instructorName, setInstructorName] = useState('');
    const [course, setCourse] = useState('');
    const [email, setEmail] = useState('');
    const [phoneNumber, setPhoneNumber] = useState('');
    const { id } = useParams();
    const [errors, setErrors] = useState({
        instructorName: '',
        course: '',
        email: '',
        phoneNumber: ''
    });
    const navigator = useNavigate();

    useEffect(() => {
        if (id) {
            getInstructor(id).then((response) => {
                setInstructorName(response.data.instructorName);
                setCourse(response.data.course);
                setEmail(response.data.email);
                setPhoneNumber(response.data.phoneNumber);
            }).catch(error => {
                console.error(error);
            });
        }

       
        document.body.style.overflow = 'hidden';
        
        return () => {
            document.body.style.overflow = 'visible';
        };
    }, []);

    function handleInstructorName(e) {
        setInstructorName(e.target.value);
    }
    function handleCourse(e) {
        setCourse(e.target.value);
    }
    function handleInstructorEmail(e) {
        setEmail(e.target.value);
    }
    function handleInstructorPhoneNumber(e) {
        setPhoneNumber(e.target.value);
    }
    function saveOrUpdateInstructor(e) {
        e.preventDefault();

        if (validateForm()) {
            const instructor = { instructorName, course, email, phoneNumber }

            if (id) {
                updateInstructor(id, instructor).then((response) => {
                    console.log(response.data);
                    navigator('/instructors');
                }).catch(error => {
                    console.error(error);
                });
            } else {
                createInstructor(instructor).then((response) => {
                    console.log(response.data);
                    navigator('/instructors')
                }).catch(error => {
                    console.error(error);
                });
            }
        }
    }
    function validateForm() {
        let valid = true;
        const errorsCopy = { ...errors }

        if (instructorName.trim()) {
            errorsCopy.instructorName = '';
        } else {
            errorsCopy.instructorName = 'Instructor Name is required';
            valid = false;
        }
        if (course.trim()) {
            errorsCopy.course = '';
        } else {
            errorsCopy.course = 'Teaching Course is required';
            valid = false;
        }
        if (email.trim()) {
            errorsCopy.email = '';
        } else {
            errorsCopy.email = 'Instructor Email is required';
            valid = false;
        }
        if (phoneNumber.trim()) {
            errorsCopy.phoneNumber = '';
        } else {
            errorsCopy.phoneNumber = 'Instructor Phone Number is Required';
            valid = false;
        }

        setErrors(errorsCopy);

        return valid;
    }

    function pageTitle() {
        if (id) {
            return <h2 className='text-center'>Update Instructor</h2>
        } else {
            return <h2 className='text-center'>Add Instructor</h2>
        }
    }

    const backgroundStyle = {
        backgroundImage: `url(${id ? updateBackgroundImage : backgroundImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        minHeight: '100vh',
        width: '100%', 
        height: '100vh',
    };

    return (
        <>
            <style>
                {`
                .container {
                    min-height: 100vh;
                }
                .card {
                    background-color: rgba(210, 180, 140, 0.8);
                    padding: 20px;
                    border-radius: 10px;
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                }
                `}
            </style>
            <div style={backgroundStyle}>
                <br /><br />
                <div className='container'>
                    <div className='row'>
                        <div className='card col-md-6 c offset-md-3 offset-md-3'>
                            {pageTitle()}
                            <div className='card-body'>
                                <form>
                                    <div className='form-group mb-2'>
                                        <label className='form-label'>Instructor Name</label>
                                        <input
                                            type='text'
                                            placeholder='Enter Instructor Name'
                                            name='Instructor Name'
                                            value={instructorName}
                                            className={`form-control ${errors.instructorName ? 'is-invalid' : ''}`}
                                            onChange={handleInstructorName}
                                        />
                                        {errors.instructorName && <div className='invalid-feedback'>{errors.instructorName}</div>}
                                    </div>
                                    <div className='form-group mb-2'>
                                        <label className='form-label'>Teaching Course</label>
                                        <input
                                            type='text'
                                            placeholder='Enter Teaching Course'
                                            name='Teaching Course'
                                            value={course}
                                            className={`form-control ${errors.course ? 'is-invalid' : ''}`}
                                            onChange={handleCourse}
                                        />
                                        {errors.course && <div className='invalid-feedback'>{errors.course}</div>}
                                    </div>
                                    <div className='form-group mb-2'>
                                        <label className='form-label'>Instructor Email</label>
                                        <input
                                            type='text'
                                            placeholder='Enter Instructor Email'
                                            name='Instructor Email'
                                            value={email}
                                            className={`form-control ${errors.email ? 'is-invalid' : ''}`}
                                            onChange={handleInstructorEmail}
                                        />
                                        {errors.email && <div className='invalid-feedback'>{errors.email}</div>}
                                    </div>
                                    <div className='form-group mb-2'>
                                        <label className='form-label'>Instructor Phone Number</label>
                                        <input
                                            type='text'
                                            placeholder='Enter Instructor Phone Number'
                                            name='Instructor Phone Number'
                                            value={phoneNumber}
                                            className={`form-control ${errors.phoneNumber ? 'is-invalid' : ''}`}
                                            onChange={handleInstructorPhoneNumber}
                                        />
                                        {errors.phoneNumber && <div className='invalid-feedback'>{errors.phoneNumber}</div>}
                                    </div>
                                    <button className='btn btn-success' onClick={saveOrUpdateInstructor}>Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <FooterComponent />
        </>
    )
}

export default InstructorComponent;

