import React, { useEffect, useState } from 'react';
import { deleteInstructor, listInstructors } from '../services/InstructorService';
import HeaderComponent from './HeaderComponent';
import FooterComponent from './FooterComponent';
import { useNavigate } from 'react-router-dom';
import SearchInstructorComponent from './SearchInstructorComponent'; 

const ListInstructorComponent = () => {
    const [instructors, setInstructors] = useState([]);
    const [filteredInstructors, setFilteredInstructors] = useState([]);
    const navigator = useNavigate();

    useEffect(() => {
        getAllInstructors();
    }, []);

    function getAllInstructors() {
        listInstructors()
            .then((response) => {
                setInstructors(response.data);
                setFilteredInstructors(response.data); 
            })
            .catch((error) => {
                console.error(error);
            });
    }

    function addNewInstructor() {
        navigator('/add-instructor');
    }

    function updateInstructor(id) {
        navigator(`/edit-instructor/${id}`);
    }

    function removeInstructor(id) {
        deleteInstructor(id)
            .then((response) => {
                getAllInstructors(); 
            })
            .catch((error) => {
                console.error(error);
            });
    }

    return (
        <>
            <HeaderComponent />
            <div className='container'>
                <SearchInstructorComponent instructors={instructors} setFilteredInstructors={setFilteredInstructors} style={{ marginBottom: '20px' }} />
                <h2 className='text-center' style={{ color: 'brown', fontSize: '35px', marginTop: '5px' }}>List of Instructors</h2>
                <button className='btn btn-outline-success mb-2' onClick={addNewInstructor}>
                    Add Instructor
                </button>
                {filteredInstructors.length > 0 ? (
                    <table className='table table-bordered border-secondary'>
                        <thead>
                            <tr>
                                <th>Instructor Id</th>
                                <th>Instructor Name</th>
                                <th>Teaching Course</th>
                                <th>Instructor Email</th>
                                <th>Instructor Phone Number</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredInstructors.map((instructor) => (
                                <tr key={instructor.id}>
                                    <td>{instructor.id}</td>
                                    <td>{instructor.instructorName}</td>
                                    <td>{instructor.course}</td>
                                    <td>{instructor.email}</td>
                                    <td>{instructor.phoneNumber}</td>
                                    <td>
                                        <button className='btn btn-outline-info' onClick={() => updateInstructor(instructor.id)}>
                                            Update
                                        </button>
                                        <button
                                            className='btn btn-outline-danger'
                                            onClick={() => removeInstructor(instructor.id)}
                                            style={{ marginLeft: '10px' }}>
                                            Delete
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                ) : (
                    <tr>
                                <td colSpan="6" className="text-center">
                                    No instrutors found
                                </td>
                            </tr>
                )}
            </div>
            <FooterComponent />
        </>
    );
};

export default ListInstructorComponent;


