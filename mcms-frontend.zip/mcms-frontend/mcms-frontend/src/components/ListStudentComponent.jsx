import React, { useEffect, useState } from 'react';
import { deleteStudent, listStudents } from '../services/StudentService';
import { useNavigate } from 'react-router-dom';
import HeaderComponent from './HeaderComponent';
import FooterComponent from './FooterComponent';
import SearchStudentComponent from './SearchStudentComponent';


const ListStudentComponent = () => {
    const [students, setStudents] = useState([]);
    const [filteredStudents, setFilteredStudents] = useState([]);
    const navigator = useNavigate();

    useEffect(() => {
        getAllStudents();
    }, []);

    function getAllStudents() {
        listStudents()
            .then((response) => {
                setStudents(response.data);
                setFilteredStudents(response.data);
            })
            .catch((error) => {
                console.error(error);
            });
    }

    function addNewStudent() {
        navigator('/add-students');
    }

    function updateStudent(id) {
        navigator(`/edit-students/${id}`);
    }

    function removeStudent(id) {
        deleteStudent(id)
            .then((response) => {
                getAllStudents();
            })
            .catch((error) => {
                console.error(error);
            });
    }

    const handleSearchInputChange = (e) => {
        const query = e.target.value.toLowerCase();
        const filteredStudents = students.filter((student) =>
            student.stdName.toLowerCase().includes(query)
        );
        setFilteredStudents(filteredStudents);
    };

    return (
        <>
            <HeaderComponent />
            <div className="container" style={{ maxHeight: '87vh', overflowY: 'auto', scrollbarWidth: 'none' }}>
                <SearchStudentComponent students={students} setFilteredStudents={setFilteredStudents} style={{ marginBottom: '20px' }} />
                <h2 className="text-center" style={{ color: 'brown', fontSize: '35px', marginTop: '5px' }}>List of Students</h2>

                <button className="btn btn-outline-success mb-2" onClick={addNewStudent}>
                    Add Student
                </button>
                <table className="table table-bordered border-secondary">
                    <thead>
                        <tr>
                            <th>Student Id</th>
                            <th>Student Name</th>
                            <th>Date Of Birth</th>
                            <th>Email</th>
                            <th>Phone Number</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredStudents.length > 0 ? (
                            filteredStudents.map((student) => (
                                <tr key={student.id}>
                                    <td>{student.id}</td>
                                    <td>{student.stdName}</td>
                                    <td>{student.dob}</td>
                                    <td>{student.email}</td>
                                    <td>{student.phoneNumber}</td>
                                    <td>
                                        <button className="btn btn-outline-info" onClick={() => updateStudent(student.id)}>
                                            Update
                                        </button>
                                        <button
                                            className="btn btn-outline-danger"
                                            onClick={() => removeStudent(student.id)}
                                            style={{ marginLeft: '10px' }}
                                        >
                                            Delete
                                        </button>
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan="6" className="text-center">
                                    No students found
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
            <FooterComponent />
        </>
    );
};

export default ListStudentComponent;













