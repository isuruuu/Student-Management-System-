import React, { useEffect, useState } from 'react';
import { createStudent, updateStudent, getStudent } from '../services/StudentService';
import backgroundImage from '../images/B.jpg';
import updateBackgroundImage from '../images/C.jpg';
import { useNavigate, useParams } from 'react-router-dom';
import FooterComponent from './FooterComponent'; 

const StudentComponent = () => {
    const [stdName, setStdName] = useState('');
    const [dob, setDob] = useState('');
    const [email, setEmail] = useState('');
    const [phoneNumber, setPhoneNumber] = useState('');
    const { id } = useParams();
    const [errors, setErrors] = useState({
        stdName: '',
        dob: '',
        email: '',
        phoneNumber: ''
    });

    const navigate = useNavigate();

    useEffect(() => {
        if (id) {
            
            getStudent(id)
                .then((response) => {
                    const { stdName, dob, email, phoneNumber } = response.data;
                    setStdName(stdName);
                    setDob(dob);
                    setEmail(email);
                    setPhoneNumber(phoneNumber);
                })
                .catch(error => {
                    console.error('Error fetching student:', error);
                });
        }
    }, [id]);

    const handleStudentName = (e) => {
        setStdName(e.target.value);
    };

    const handleStudentDob = (e) => {
        setDob(e.target.value);
    };

    const handleStudentEmail = (e) => {
        setEmail(e.target.value);
    };

    const handleStudentPhoneNumber = (e) => {
        setPhoneNumber(e.target.value);
    };

    const saveOrUpdateStudent = async (e) => {
        e.preventDefault();
        const isValid = validateForm();
        if (isValid) {
            const student = {
                stdName: stdName,
                dob: dob,
                email: email,
                phoneNumber: phoneNumber
            };

            try {
                if (id) {
                    await updateStudent(id, student);
                    console.log('Student updated successfully');
                } else {
                    await createStudent(student);
                    console.log('Student created successfully');
                }
                navigate('/students');
            } catch (error) {
                console.error('Error saving student:', error);
            }
        }
    };

    const validateForm = () => {
        let valid = true;
        const errorsCopy = { ...errors };

        if (!stdName.trim()) {
            errorsCopy.stdName = 'Student Name is required';
            valid = false;
        } else {
            errorsCopy.stdName = '';
        }

        if (!dob.trim()) {
            errorsCopy.dob = 'Student Date of Birth is required';
            valid = false;
        } else {
            errorsCopy.dob = '';
        }

        if (!email.trim()) {
            errorsCopy.email = 'Student Email is required';
            valid = false;
        } else {
            errorsCopy.email = '';
        }

        if (!phoneNumber.trim()) {
            errorsCopy.phoneNumber = 'Student Phone Number is required';
            valid = false;
        } else {
            errorsCopy.phoneNumber = '';
        }

        setErrors(errorsCopy);
        return valid;
    };

    const bgImage = pageTitle() === 'Update Student' ? updateBackgroundImage : backgroundImage;

    function pageTitle() {
        return id ? 'Update Student' : 'Add Student';
    }

    return (
        <>
            <style>
                {`
                body {
                    margin: 0;
                    padding: 0;
                    background-image: url('${bgImage}');
                    background-size: cover;
                    background-position: center;
                }
                .container {
                    min-height: 100vh;
                
                }
                .card{
                    background-color: rgba(210, 180, 140, 0.8);
                    padding: 20px; 
                    border-radius: 10px; 
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 

                }
             
                `}
            </style>
            <div className='container'>
                <br></br>
                <div className='row'>
                    <div className='card col-md-6 offset-md-3 offset-md-3'>
                        <h2 className='text-center'>{pageTitle()}</h2>
                        <div className='card-body'>
                            <form>
                                <div className='form-group mb-2'>
                                    <label className='form-label'>Student Name</label>
                                    <input
                                        type='text'
                                        placeholder='Enter Student Name'
                                        name='stdName'
                                        value={stdName}
                                        className={`form-control ${errors.stdName ? 'is-invalid' : ''}`}
                                        onChange={handleStudentName}
                                    />
                                    {errors.stdName && <div className='invalid-feedback'>{errors.stdName}</div>}
                                </div>
                                <div className='form-group mb-2'>
                                    <label className='form-label'>Enter Student Date of Birth</label>
                                    <input
                                        type='text'
                                        placeholder='Date/Month/Year'
                                        name='dob'
                                        value={dob}
                                        className={`form-control ${errors.dob ? 'is-invalid' : ''}`}
                                        onChange={handleStudentDob}
                                    />
                                    {errors.dob && <div className='invalid-feedback'>{errors.dob}</div>}
                                </div>
                                <div className='form-group mb-2'>
                                    <label className='form-label'>Student Email</label>
                                    <input
                                        type='text'
                                        placeholder='Enter Student Email'
                                        name='email'
                                        value={email}
                                        className={`form-control ${errors.email ? 'is-invalid' : ''}`}
                                        onChange={handleStudentEmail}
                                    />
                                    {errors.email && <div className='invalid-feedback'>{errors.email}</div>}
                                </div>
                                <div className='form-group mb-2'>
                                    <label className='form-label'>Student Phone Number</label>
                                    <input
                                        type='text'
                                        placeholder='Enter Student Phone Number'
                                        name='phoneNumber'
                                        value={phoneNumber}
                                        className={`form-control ${errors.phoneNumber ? 'is-invalid' : ''}`}
                                        onChange={handleStudentPhoneNumber}
                                    />
                                    {errors.phoneNumber && <div className='invalid-feedback'>{errors.phoneNumber}</div>}
                                </div>
                                <button className='btn btn-success' onClick={saveOrUpdateStudent}>
                                    Submit
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <FooterComponent />
        </>
    );
};

export default StudentComponent;




