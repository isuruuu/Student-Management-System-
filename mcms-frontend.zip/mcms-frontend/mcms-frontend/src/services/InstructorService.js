import axios from "axios";

const REST_API_BASE_URL = 'http://localhost:8080/api/instructors'; 

export const listInstructors = () => {
    return axios.get(REST_API_BASE_URL);
}

export const createInstructor = (instructor) => axios.post(REST_API_BASE_URL, instructor);

export const getInstructor = (instructorId) => axios.get(REST_API_BASE_URL + '/' +instructorId);

export const updateInstructor = (instructorId, instructor) => axios.put(REST_API_BASE_URL + '/' + instructorId, instructor);

export const deleteInstructor = (instructorId) => axios.delete(REST_API_BASE_URL + '/' + instructorId);