
import './App.css'

import LoginComponent from "./components/LoginComponent"
import ListStundentComponent from "./components/ListStudentComponent"
import { BrowserRouter, Route, Routes } from "react-router-dom"
import StudentComponent from "./components/StudentComponent"
import HomeComponent from "./components/HomeComponent"
import AboutUsComponent from "./components/AboutUsComponent"
import ListCourseComponent from "./components/ListCourseComponent"
import CourseComponent from "./components/CourseComponent"
import ListInstructorComponent from "./components/ListInstructorComponent"
import InstructorComponent from "./components/InstructorComponent"
import UserComponent from './components/UserComponent'
import LoginAdminComponent from './components/LoginAdminComponent'
import UserList from './components/UserListComponent'
import MainComponent from './components/MainComponent'


function App() {
 

  return (
    <>

    <BrowserRouter>

    <Routes>
      
                {/* // http://localhost:3000  */}
                <Route path='/' element = {<HomeComponent/> }></Route>
     
                {/* // http://localhost:3000/login  */}
                <Route path='/login' element = {<LoginComponent/> }></Route>

                 {/* // http://localhost:3000/students  */}
                 <Route path='/students' element = {<ListStundentComponent/> }></Route>
      
                 {/* // http://localhost:3000/add-students  */}
                 <Route path='/add-students' element = {<StudentComponent/> }></Route>

                  {/* // http://localhost:3000/edit-students/1  */}
                  <Route path='/edit-students/:id' element = {<StudentComponent/> }></Route>

                  {/* // http://localhost:3000/aboutUs  */}
                  <Route path='/aboutUs' element = {<AboutUsComponent/> }></Route>

                  {/* // http://localhost:3000/courses  */}
                  <Route path='/courses' element = {<ListCourseComponent/> }></Route>

                  {/* // http://localhost:3000/add-course  */}
                  <Route path='/add-course' element = {<CourseComponent/> }></Route>

                  {/* // http://localhost:3000/edit-course/1  */}
                  <Route path='/edit-course/:id' element = {<CourseComponent/> }></Route>

                  {/* // http://localhost:3000/instructors  */}
                  <Route path='/instructors' element = {<ListInstructorComponent/> }></Route>

                  {/* // http://localhost:3000/add-instructor  */}
                  <Route path='/add-instructor' element = {<InstructorComponent/> }></Route>

                  {/* // http://localhost:3000/edit-instructor/1  */}
                  <Route path='/edit-instructor/:id' element = {<InstructorComponent/> }></Route>

                   {/* // http://localhost:3000/user  */}
                  <Route path='/user' element = {<UserComponent/> }></Route>
                  
                  {/* // http://localhost:3000/adminLogin  */}
                  <Route path='/adminLogin' element = {<LoginAdminComponent/> }></Route>

                  {/* // http://localhost:3000/userList  */}
                  <Route path='/userList' element = {<UserList/> }></Route>

                  {/* // http://localhost:3000/dashboard  */}
                  <Route path='/dashboard' element = {<MainComponent/> }></Route>


                       

    </Routes>

    </BrowserRouter>

    </>
  )
}

export default App
