package Rhythmic.Realm.mcmsbackend.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "courses")
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "Course_name", nullable = false, unique = true)
    private String courseName;

    @Column(name = "Description")
    private String description;

    @Column(name = "instructor", nullable = false)
    private String instructor;


}
