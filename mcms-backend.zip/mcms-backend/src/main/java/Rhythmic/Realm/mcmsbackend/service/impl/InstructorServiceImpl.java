package Rhythmic.Realm.mcmsbackend.service.impl;

import Rhythmic.Realm.mcmsbackend.dto.InstructorDto;
import Rhythmic.Realm.mcmsbackend.entity.Instructor;
import Rhythmic.Realm.mcmsbackend.exception.ResourceNotFoundException;
import Rhythmic.Realm.mcmsbackend.mapper.InstructorMapper;
import Rhythmic.Realm.mcmsbackend.repository.InstructorRepository;
import Rhythmic.Realm.mcmsbackend.service.InstructorService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class InstructorServiceImpl implements InstructorService {
    private InstructorRepository instructorRepository;

    @Override
    public InstructorDto createInstructor(InstructorDto instructorDto) {
        Instructor instructor = InstructorMapper.mapToInstructor(instructorDto);
        Instructor savedInstructor = instructorRepository.save(instructor);
        return InstructorMapper.mapToInstructorDto(savedInstructor);
    }

    @Override
    public InstructorDto getInstructorById(Long instructorId) {
        Instructor instructor = instructorRepository.findById(instructorId)
                .orElseThrow(() -> new ResourceNotFoundException("Instructor not found with ID: " + instructorId));
        return InstructorMapper.mapToInstructorDto(instructor);
    }

    @Override
    public List<InstructorDto> getAllInstructors() {
        List<Instructor> instructors = instructorRepository.findAll();
        return instructors.stream().map(InstructorMapper::mapToInstructorDto).collect(Collectors.toList());
    }

    @Override
    public InstructorDto updateInstructor(Long instructorId, InstructorDto updatedInstructor) {
        Instructor instructor = instructorRepository.findById(instructorId)
                .orElseThrow(() -> new ResourceNotFoundException("Instructor not found with ID: " + instructorId));
        instructor.setInstructorName(updatedInstructor.getInstructorName());
        instructor.setCourse(updatedInstructor.getCourse());
        instructor.setEmail(updatedInstructor.getEmail());
        instructor.setPhoneNumber(updatedInstructor.getPhoneNumber());
        Instructor updatedInstructorObj = instructorRepository.save(instructor);
        return InstructorMapper.mapToInstructorDto(updatedInstructorObj);
    }

    @Override
    public void deleteInstructor(Long instructorId) {
        if (!instructorRepository.existsById(instructorId)) {
            throw new ResourceNotFoundException("Instructor not found with ID: " + instructorId);
        }
        instructorRepository.deleteById(instructorId);
    }
}
