package Rhythmic.Realm.mcmsbackend.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class CourseDto {
    private Long id;
    private String courseName;
    private String description;
    private String instructor;
}
