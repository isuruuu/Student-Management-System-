package Rhythmic.Realm.mcmsbackend.mapper;

import Rhythmic.Realm.mcmsbackend.dto.CourseDto;
import Rhythmic.Realm.mcmsbackend.entity.Course;

public class CourseMapper {
    public static CourseDto mapToCourseDto(Course course) {
        return new CourseDto(
                course.getId(),
                course.getCourseName(),
                course.getDescription(),
                course.getInstructor()
        );
    }
    public static Course mapToCourse(CourseDto courseDto){
    return new Course(
            courseDto.getId(),
            courseDto.getCourseName(),
            courseDto.getDescription(),
            courseDto.getInstructor()
    );
    }
}

