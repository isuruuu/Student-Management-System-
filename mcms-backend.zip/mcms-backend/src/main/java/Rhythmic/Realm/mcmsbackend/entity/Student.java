package Rhythmic.Realm.mcmsbackend.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "students")
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "Student_name", nullable = false, unique = true)
    private String stdName;

    @Column(name = "Date_of_birth")
    private String dob;

    @Column(name = "Ëmail_id", nullable = false, unique = true)
    private String email;

    @Column(name = "Phone_number")
    private String phoneNumber;
}
