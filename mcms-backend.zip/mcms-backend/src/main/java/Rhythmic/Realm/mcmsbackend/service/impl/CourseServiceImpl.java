package Rhythmic.Realm.mcmsbackend.service.impl;

import Rhythmic.Realm.mcmsbackend.dto.CourseDto;
import Rhythmic.Realm.mcmsbackend.entity.Course;
import Rhythmic.Realm.mcmsbackend.exception.ResourceNotFoundException;
import Rhythmic.Realm.mcmsbackend.mapper.CourseMapper;
import Rhythmic.Realm.mcmsbackend.repository.CourseRepository;
import Rhythmic.Realm.mcmsbackend.service.CourseService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class CourseServiceImpl implements CourseService {
    private final CourseRepository courseRepository;

    @Override
    public CourseDto createCourse(CourseDto courseDto) {
        Course course = CourseMapper.mapToCourse(courseDto);
        Course savedCourse = courseRepository.save(course);
        return CourseMapper.mapToCourseDto(savedCourse);
    }

    @Override
    public CourseDto getCourseById(Long courseId) {
        Course course = courseRepository.findById(courseId)
                .orElseThrow(() -> new ResourceNotFoundException("Course does not exist with ID: " + courseId));
        return CourseMapper.mapToCourseDto(course);
    }

    @Override
    public List<CourseDto> getAllCourses() {
        List<Course> courses = courseRepository.findAll();
        return courses.stream().map(CourseMapper::mapToCourseDto).collect(Collectors.toList());
    }

    @Override
    public CourseDto updateCourse(Long courseId, CourseDto updatedCourse) {
        Course course = courseRepository.findById(courseId)
                .orElseThrow(() -> new ResourceNotFoundException("Course does not exist with ID: " + courseId));
        course.setCourseName(updatedCourse.getCourseName());
        course.setDescription(updatedCourse.getDescription());
        course.setInstructor(updatedCourse.getInstructor());
        // Add more fields if needed

        Course updatedCourseObj = courseRepository.save(course);
        return CourseMapper.mapToCourseDto(updatedCourseObj);
    }

    @Override
    public void deleteCourse(Long courseId) {
        if (!courseRepository.existsById(courseId)) {
            throw new ResourceNotFoundException("Course does not exist with ID: " + courseId);
        }
        courseRepository.deleteById(courseId);
    }
}
