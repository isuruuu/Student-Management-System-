package Rhythmic.Realm.mcmsbackend.controller;


import Rhythmic.Realm.mcmsbackend.exception.UserNotFoundException;
import Rhythmic.Realm.mcmsbackend.entity.User;
import Rhythmic.Realm.mcmsbackend.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import java.util.List;

@CrossOrigin("*")
@RestController
@RequestMapping("/api/users")

public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/all")
    public ResponseEntity<List<User>> getUsers() {
        List<User> users = userService.getUsers();
        return ResponseEntity.ok(users);
    }

    @PostMapping("/login")
    public ResponseEntity<User> loginUser(@RequestBody User loginRequest) {
        try {

            String email = loginRequest.getEmail();
            String password = loginRequest.getPassword();


            User user = userService.authenticateUser(email, password);

            return ResponseEntity.ok(user);
        } catch (UserNotFoundException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
        }
    }



    @PostMapping("/add")
    public ResponseEntity<Void> registerNewUser(@javax.validation.Valid @RequestBody User user) {
        userService.addNewUser(user);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }


    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteUserById(@PathVariable Long id) {
        userService.deleteUserById(id);
        return ResponseEntity.noContent().build();
    }
}

