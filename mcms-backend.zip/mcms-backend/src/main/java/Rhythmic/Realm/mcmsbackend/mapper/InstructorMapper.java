package Rhythmic.Realm.mcmsbackend.mapper;

import Rhythmic.Realm.mcmsbackend.dto.InstructorDto;
import Rhythmic.Realm.mcmsbackend.entity.Instructor;

public class InstructorMapper {
    public static InstructorDto mapToInstructorDto(Instructor instructor) {
        return new InstructorDto(
                instructor.getId(),
                instructor.getInstructorName(),
                instructor.getCourse(),
                instructor.getEmail(),
                instructor.getPhoneNumber()
        );
    }

    public static Instructor mapToInstructor(InstructorDto instructorDto) {
        return new Instructor(
                instructorDto.getId(),
                instructorDto.getInstructorName(),
                instructorDto.getCourse(),
                instructorDto.getEmail(),
                instructorDto.getPhoneNumber()
        );
    }
}
