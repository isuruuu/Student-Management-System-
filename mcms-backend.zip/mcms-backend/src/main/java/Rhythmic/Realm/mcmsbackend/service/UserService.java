package Rhythmic.Realm.mcmsbackend.service;

import Rhythmic.Realm.mcmsbackend.exception.UserExistsException;
import Rhythmic.Realm.mcmsbackend.exception.UserNotFoundException;
import Rhythmic.Realm.mcmsbackend.entity.User;
import Rhythmic.Realm.mcmsbackend.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public List<User> getUsers() {
        return userRepository.findAll();
    }

    public User authenticateUser(String email, String password) {
        Optional<User> userOptional = userRepository.findUserByEmail(email);
        if (userOptional.isPresent()) {
            User user = userOptional.get();
            if (!user.getPassword().equals(password)) {
                throw new UserNotFoundException("Password is not correct for email: " + email);
            }
            return user;
        } else {
            throw new UserNotFoundException("User with email " + email + " not found.");
        }
    }

    public void addNewUser(User user) {
        Optional<User> existingUser = userRepository.findUserByEmail(user.getEmail());
        if (existingUser.isPresent()) {
            throw new UserExistsException("Email already exists: " + user.getEmail());
        }
        userRepository.save(user);
    }

    public void deleteUserById(Long id) {
        Optional<User> userOptional = userRepository.findById(id);
        if (userOptional.isPresent()) {
            User user = userOptional.get();
            userRepository.delete(user);
        } else {
            throw new UserNotFoundException("User with ID " + id + " not found.");
        }
    }


}

