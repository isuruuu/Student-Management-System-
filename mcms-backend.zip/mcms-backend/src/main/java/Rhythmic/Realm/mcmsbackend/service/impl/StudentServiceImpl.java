package Rhythmic.Realm.mcmsbackend.service.impl;

import Rhythmic.Realm.mcmsbackend.dto.StudentDto;
import Rhythmic.Realm.mcmsbackend.entity.Student;
import Rhythmic.Realm.mcmsbackend.exception.ResourceNotFoundException;
import Rhythmic.Realm.mcmsbackend.mapper.StudentMapper;
import Rhythmic.Realm.mcmsbackend.repository.StudentRepository;
import Rhythmic.Realm.mcmsbackend.service.StudentService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class StudentServiceImpl implements StudentService {
    private StudentRepository studentRepository;
    @Override
    public StudentDto createStudent(StudentDto studentDto) {

        Student student = StudentMapper.mapToStudent(studentDto);
        Student savedStudent = studentRepository.save(student);

        return StudentMapper.mapToStudentDto(savedStudent);
    }

    @Override
    public StudentDto getStudentById(Long studentId) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new ResourceNotFoundException("student is not exist with given Id : "+studentId));
        return StudentMapper.mapToStudentDto(student);
    }

    @Override
    public List<StudentDto> getAllStudents() {
        List<Student> students = studentRepository.findAll();
        return students.stream().map(StudentMapper::mapToStudentDto)
                .collect(Collectors.toList());
    }

    @Override
    public <updatedStudent> StudentDto updateStudent(Long studentId, StudentDto updatedStudent) {
        Student student =  studentRepository.findById(studentId).orElseThrow(() -> new ResourceNotFoundException("Student is not exists with given id: "+studentId));
        student.setStdName(updatedStudent.getStdName());
        student.setDob(updatedStudent.getDob());

        if (updatedStudent.getEmail() != null) {
            student.setEmail(updatedStudent.getEmail());
        } else {
            // Handle the case where email is null, either by throwing an exception or setting a default value.
            throw new IllegalArgumentException("Email cannot be null");
        }
        student.setPhoneNumber(updatedStudent.getPhoneNumber());

        Student updatedStudentObj = studentRepository.save(student);

        return StudentMapper.mapToStudentDto(updatedStudentObj);

    }

    @Override
    public void deleteStudent(Long studentId) {

        Student student =  studentRepository.findById(studentId).orElseThrow(() -> new ResourceNotFoundException("Student is not exists with given id: "+studentId));
        studentRepository.deleteById(studentId);

    }


}
