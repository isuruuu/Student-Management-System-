package Rhythmic.Realm.mcmsbackend.service;

import Rhythmic.Realm.mcmsbackend.dto.InstructorDto;

import java.util.List;

public interface InstructorService {
    InstructorDto createInstructor(InstructorDto instructorDto);

    InstructorDto getInstructorById(Long instructorId);

    List<InstructorDto> getAllInstructors();

    InstructorDto updateInstructor(Long instructorId, InstructorDto updatedInstructor);

    void deleteInstructor(Long instructorId);
}
