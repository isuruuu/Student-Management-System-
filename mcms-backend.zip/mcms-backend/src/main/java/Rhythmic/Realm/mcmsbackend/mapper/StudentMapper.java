package Rhythmic.Realm.mcmsbackend.mapper;

import Rhythmic.Realm.mcmsbackend.dto.StudentDto;
import Rhythmic.Realm.mcmsbackend.entity.Student;

public class StudentMapper {
    public static StudentDto mapToStudentDto(Student student){
        return new StudentDto(
                student.getId(),
                student.getStdName(),
                student.getDob(),
                student.getEmail(),
                student.getPhoneNumber()
        );
    }

    public static Student mapToStudent(StudentDto studentDto){
        return new Student(
                studentDto.getId(),
                studentDto.getStdName(),
                studentDto.getDob(),
                studentDto.getEmail(),
                studentDto.getPhoneNumber()
        );
    }
}
