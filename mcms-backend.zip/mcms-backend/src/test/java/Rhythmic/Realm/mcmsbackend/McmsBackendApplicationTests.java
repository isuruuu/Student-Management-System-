package Rhythmic.Realm.mcmsbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class McmsBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
